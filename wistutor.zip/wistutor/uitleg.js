document.addEventListener("DOMContentLoaded", function() {
    // Object met uitleg en stappenplannen voor verschillende wiskundige termen en bewerkingen
    const wiskundeTutor = {
        termen: {
            optellen: {
                uitleg: "Optellen is het samenvoegen van twee of meer getallen om hun totale waarde te vinden.",
                stappen: [
                    "Schrijf de getallen onder elkaar.",
                    "Begin met het optellen van de cijfers in de eenhedenkolom.",
                    "Ga verder naar de tientallenkolom, honderdtallenkolom, enz.",
                    "Vergeet niet om eventuele onthoudingen (carry-overs) mee te nemen."
                ]
            },
            aftrekken: {
                uitleg: "Aftrekken is het weghalen van een getal van een ander getal om het verschil te vinden.",
                stappen: [
                    "Schrijf de getallen onder elkaar.",
                    "Begin met het aftrekken van de cijfers in de eenhedenkolom.",
                    "Ga verder naar de tientallenkolom, honderdtallenkolom, enz.",
                    "Als het bovenste cijfer kleiner is dan het onderste, leen dan van de volgende kolom."
                ]
            },
            vermenigvuldigen: {
                uitleg: "Vermenigvuldigen is het herhaaldelijk optellen van een getal een bepaald aantal keren.",
                stappen: [
                    "Schrijf de getallen onder elkaar.",
                    "Vermenigvuldig het onderste cijfer met elk cijfer van het bovenste getal.",
                    "Schuif elke volgende rij naar links als je een nieuwe kolom begint.",
                    "Tel de resultaten van elke rij bij elkaar op."
                ]
            },
            delen: {
                uitleg: "Delen is het verdelen van een getal in een bepaald aantal gelijke delen.",
                stappen: [
                    "Bepaal hoe vaak de deler in het eerste deel van het deeltal past.",
                    "Schrijf dat getal boven de lijn.",
                    "Vermenigvuldig de deler met dat getal en trek het resultaat af van het deeltal.",
                    "Herhaal het proces met de rest."
                ]
            },
            wortel: {
                uitleg: "Wortels zijn het omgekeerde van kwadraten.",
                stappen: [
                    "gebruik logica. als het getal waarvan je de wortel wil berekenen laag is, is het antwoord ook laag",
                    "ga een reeks getallen af. kijk naar de wortel van 169 je weet dat 10x10 100 is dus het antwoord is boven de 10",
                    "als het na deze stappen niet lukt omdat het antwoord geen heel getal is, gebruik dan een rekenmachine",
                ]
            },
        },
        uitleg: function(term) {
            if (this.termen[term]) {
                return `Uitleg voor ${term}: ${this.termen[term].uitleg}`;
            } else {
                return `Sorry, ik heb geen uitleg voor de term: ${term}`;
            }
        },
        stappenplan: function(term) {
            if (this.termen[term]) {
                let antwoord = `Stappenplan voor ${term}:\n`;
                this.termen[term].stappen.forEach((stap, index) => {
                    antwoord += `${index + 1}. ${stap}\n`;
                });
                return antwoord;
            } else {
                return `Sorry, ik heb geen stappenplan voor de term: ${term}`;
            }
        },
        verwerkVraag: function(vraag) {
            const vraagZonderSpaties = vraag.trim().toLowerCase();
            if (vraagZonderSpaties.includes('optellen')) {
                return 'optellen';
            } else if (vraagZonderSpaties.includes('aftrekken')) {
                return 'aftrekken';
            } else if (vraagZonderSpaties.includes('vermenigvuldigen')) {
                return 'vermenigvuldigen';
            } else if (vraagZonderSpaties.includes('delen')) {
                return 'delen';
            } else if (vraagZonderSpaties.includes('wortel')) {
                return 'wortel';
            } else {
                return null;
            }
        }
    };

    function getHint() {
        const vraag = document.getElementById('vraag').value;
        const term = wiskundeTutor.verwerkVraag(vraag);
        const antwoord = term ? wiskundeTutor.stappenplan(term) : 'Sorry, ik begrijp de vraag niet. Kijk nog een keer of de spelling goed is.';
        document.getElementById('result').value = antwoord;
    }

    function explainSolution() {
        const vraag = document.getElementById('vraag').value;
        const term = wiskundeTutor.verwerkVraag(vraag);
        const antwoord = term ? wiskundeTutor.uitleg(term) : 'Sorry, ik begrijp de vraag niet. Probeer iets als "wat is optellen" of "wat is aftrekken".';
        document.getElementById('result').value = antwoord;
    }

    // Event listeners voor de knoppen
    document.getElementById('getHint').addEventListener('click', getHint);
    document.getElementById('explainSolution').addEventListener('click', explainSolution);
});
